const menuToggle = document.getElementById("menuToggle");
const navMenu = document.getElementById("navMenu");
const filterButtons = document.querySelectorAll(".filter-btn");
const postCards = document.querySelectorAll(".post-card");
const readMoreButtons = document.querySelectorAll(".read-more");
const footerText = document.getElementById("footerText");

if (menuToggle && navMenu) {
    menuToggle.addEventListener("click", () => {
        navMenu.classList.toggle("show");
    });
}

if (filterButtons.length && postCards.length) {
    filterButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const filter = button.dataset.filter;

            filterButtons.forEach((item) => item.classList.remove("active"));
            button.classList.add("active");

            postCards.forEach((card) => {
                const category = card.dataset.category;
                const shouldShow = filter === "all" || category === filter;
                card.style.display = shouldShow ? "block" : "none";
            });
        });
    });
}

if (readMoreButtons.length) {
    readMoreButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const card = button.closest(".post-card");
            const expanded = card.classList.toggle("expanded");
            button.textContent = expanded ? "Ocultar resumo" : "Ler resumo";
        });
    });
}

if (footerText) {
    footerText.textContent = `© ${new Date().getFullYear()} SecSphere - Projeto acadêmico de cibersegurança.`;
}
